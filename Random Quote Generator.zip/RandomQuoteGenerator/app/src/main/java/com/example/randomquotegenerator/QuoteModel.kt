package com.example.randomquotegenerator

data class QuoteModel(val quote: String, val author: String)