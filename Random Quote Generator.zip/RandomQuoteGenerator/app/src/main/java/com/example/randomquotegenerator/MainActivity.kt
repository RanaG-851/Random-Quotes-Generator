package com.example.randomquotegenerator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.content.Intent
import androidx.appcompat.widget.Toolbar
import android.app.AlertDialog
import android.content.DialogInterface

class MainActivity : AppCompatActivity() {
    private lateinit var quoteTextView: TextView
    private lateinit var authorTextView: TextView
    private lateinit var generateButton: Button
    private lateinit var shareButton: Button
    private lateinit var quoteRepository: QuoteRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        quoteTextView = findViewById(R.id.quote_textview)
        authorTextView = findViewById(R.id.author_textview)
        generateButton = findViewById(R.id.generate_button)
        shareButton = findViewById(R.id.share_button)

        quoteRepository = QuoteRepository(this)

        generateButton.setOnClickListener {
            val quote = quoteRepository.getRandomQuote()
            displayQuote(quote)
        }

        shareButton.setOnClickListener {
            shareQuote()
        }
    }

    private fun displayQuote(quote: QuoteModel) {
        quoteTextView.text = quote.quote
        authorTextView.text = quote.author
    }

    private fun shareQuote() {
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.type = "text/plain"
        shareIntent.putExtra(Intent.EXTRA_TEXT, "${quoteTextView.text} - ${authorTextView.text}")
        startActivity(Intent.createChooser(shareIntent, "Share Quote"))
    }

    override fun onBackPressed() {
        val alertDialog = AlertDialog.Builder(this)
        alertDialog.setTitle("Exit")
        alertDialog.setMessage("Are you sure you want to exit the app?")
        alertDialog.setPositiveButton("Yes") { _, _ ->
            super.onBackPressed()
        }
        alertDialog.setNegativeButton("No") { _, _ ->
            // Do nothing
        }
        alertDialog.show()
    }
}