package com.example.randomquotegenerator

import kotlin.random.Random

class QuoteAdapter(private val quotes: List<QuoteModel>) {
    fun getRandomQuote(): QuoteModel {
        val random = java.util.Random()
        return quotes[random.nextInt(quotes.size)]
    }
}