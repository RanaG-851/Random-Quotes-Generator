package com.example.randomquotegenerator

import android.content.Context

class QuoteRepository(private val context: Context) {
    private val quotes: MutableList<QuoteModel> = mutableListOf()

    init {
        quotes.add(QuoteModel("Believe you can and you're halfway there.", "Theodore Roosevelt"))
        quotes.add(QuoteModel("The only way to do great work is to love what you do.", "Steve Jobs"))
        quotes.add(QuoteModel("The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well.", " Ralph Waldo Emerson"))
        quotes.add(QuoteModel("Twenty years from now you will be more disappointed by the things that you didn’t do than by the ones you did do. So throw off the bowlines, sail away from safe harbor, catch the trade winds in your sails. Explore, Dream, Discover.",  "Mark Twain"))
        quotes.add(QuoteModel("The difference between ordinary and extraordinary is that little extra.", "Jimmy Johnson"))
        quotes.add(QuoteModel("It is during our darkest moments that we must focus to see the light.","Aristotle"))
        quotes.add(QuoteModel("The mind is everything. What you think you become.","Buddha"))
        quotes.add(QuoteModel("The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.","Helen Keller"))
        quotes.add(QuoteModel("There is nothing impossible to him who will try.","Alexander the Great"))
        quotes.add(QuoteModel("The only person you are destined to become is the person you decide to be.","Ralph Waldo Emerson"))
        quotes.add(QuoteModel("You don't have to be great to start, but you have to start to be great.","Zig Ziglar"))
        quotes.add(QuoteModel("If you can dream it, you can do it.","Walt Disney"))
        quotes.add(QuoteModel("Our greatest glory is not in never falling, but in rising every time we fall."," Nelson Mandela"))
        quotes.add(QuoteModel("The future belongs to those who believe in the beauty of their dreams.","Eleanor Roosevelt"))
        quotes.add(QuoteModel("The only limit to our realization of tomorrow will be our doubts of today.","Franklin D. Roosevelt"))
        quotes.add(QuoteModel("The best way to predict the future is to create it.","Peter Drucker"))
        quotes.add(QuoteModel("You miss 100% of the shots you don’t take.","Wayne Gretzky"))
        quotes.add(QuoteModel("The only way to do great work is to love what you do.", "Steve Jobs"))
        quotes.add(QuoteModel("The journey of a thousand miles begins with a single step.","Lao Tzu"))
        quotes.add(QuoteModel("Whether you think you can or you think you can't, you're right.","Henry Ford"))
        quotes.add(QuoteModel("The mind is not a vessel to be filled, but a fire to be kindled.","Plutarch"))
        quotes.add(QuoteModel("Education is the most powerful weapon which you can use to change the world.","Nelson Mandela"))
        quotes.add(QuoteModel("A life is not important except in the impact it has on other lives.","George Eliot"))
        quotes.add(QuoteModel("The only true wisdom is in knowing you know nothing.","Socrates"))
        quotes.add(QuoteModel("The unexamined life is not worth living.","Socrates"))
        quotes.add(QuoteModel("Curiosity about life in all its aspects, I think, is the secret of great creative people.","Leo Burnett"))
        quotes.add(QuoteModel("Innovation distinguishes between a leader and a follower.","Steve Jobs"))
        quotes.add(QuoteModel("The important thing is not to stop questioning. Curiosity has its own reason for existing.","Albert Einstein"))
        quotes.add(QuoteModel("The only source of knowledge is experience.","Albert Einstein"))
        quotes.add(QuoteModel("Life is what happens when you’re busy making other plans.","John Lennon"))
        quotes.add(QuoteModel("The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.","Helen Keller"))
        quotes.add(QuoteModel("If you can dream it, you can do it.","Walt Disney"))
        quotes.add(QuoteModel("The only person you are destined to become is the person you decide to be.","Ralph Waldo Emerson"))
        quotes.add(QuoteModel("The mind is everything. What you think you become.","Buddha"))
        quotes.add(QuoteModel("There is nothing impossible to him who will try.","Alexander the Great"))
        quotes.add(QuoteModel("The difference between ordinary and extraordinary is that little extra.","Jimmy Johnson"))

    }

    fun getRandomQuote(): QuoteModel {
        return QuoteAdapter(quotes).getRandomQuote()
    }
}